﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Examen_unidad_2_profe_Eric.Examen
{
    internal class Ejercicios
    {
        public void Ejercio1()
        {
            int total = 0;
            int[,] productos = new int[5,4]
            {
                { 500, 3000, 100, 400},
                { 1000, 150, 200, 500 },
                { 250, 1800, 2900, 300},
                { 400, 130, 90, 2400},
                { 60, 20, 4000, 3600},
            };


            for (int columnas = 0; columnas < 4; columnas++)
            {
                
                for (int fila = 0; fila < 3; fila++)
                {
                    total += productos[fila, columnas];
                }
                Console.WriteLine($"El vendedor {columnas + 1} tuvo una ganancia de {total} pesos.");
            }
            Console.WriteLine();

            
            for (int fila = 0; fila < 3; fila++)
            {
                
                for (int columnas = 0; columnas < 4; columnas++)
                {
                    total += productos[fila, columnas];
                }
                Console.WriteLine($"El producto {fila + 1} generó {total} pesos de ganancia.");
            }

        }
    }
}
