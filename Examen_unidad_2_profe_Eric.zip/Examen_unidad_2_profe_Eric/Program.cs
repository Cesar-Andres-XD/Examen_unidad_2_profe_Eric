﻿using Examen_unidad_2_profe_Eric.Examen;
using System;

namespace Examen_unidad_2_profe_Eric
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Ejercicios ejercicios = new Ejercicios();

            ejercicios.Ejercio1();
        }
    }
}